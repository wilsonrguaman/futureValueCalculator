﻿using Microsoft.AspNetCore.Mvc;
using WilsonGuamanFutureValue2.FutureValueModel;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

//namespace WilsonGuamanFutureValue2.Controllers
//{
public class HomeController : Controller
{
    [HttpGet]
    // GET: /<controller>/
    public IActionResult Index()
    {
        // ViewBag.Name = "Mary";
        //ViewBag.FV = 99999.99;
        ViewBag.FV = 0;
        return View();
    }
    [HttpPost]
    public IActionResult Index(FutureValueModel model)
    {
        if (ModelState.IsValid)
        {
            ViewBag.FV = model.CalculateFutureValue();
        }
        else
        {
            ViewBag.FV = 0;
        }
        return View(model);
    }

}
//}